(function () { "use strict";
var brian151 = {};
brian151.Main = function() { };
brian151.Main.main = function() {
};
brian151.Main.main();
})();
