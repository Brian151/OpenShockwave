Parser is being ported to haxe.
It still will be compiled to JS/HTML5, Haxe is just a much prettier source format to work with.
Current status: RIFF.js mostly ported, untested